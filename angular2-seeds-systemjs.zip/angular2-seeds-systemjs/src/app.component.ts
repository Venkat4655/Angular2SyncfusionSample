import {Component, ViewEncapsulation} from '@angular/core';

@Component({
  selector: 'ej-app',
  templateUrl: 'src/app.component.html',
  styleUrls:['src/app.component.css']
})
export class AppComponent {
}