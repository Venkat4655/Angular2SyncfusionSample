import { Component } from '@angular/core';

@Component({
    selector: 'ej-app',
    templateUrl: 'src/home/home.component.html',
})
export class HomeComponent {
}
